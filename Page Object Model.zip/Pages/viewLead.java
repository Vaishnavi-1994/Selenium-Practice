package Pages;

import Base.ProjectSpecificMethods;

public class viewLead extends ProjectSpecificMethods
{

}
